# Rupali & Nirbhay wedding invitation source

This archive contains the wedding invitation app and the shared workspace files
needed to build it.

## Run inside the Replit pnpm workspace

From the extracted workspace root:

```sh
pnpm install
pnpm --filter @workspace/royal-wedding-invite run dev
```

To verify the source:

```sh
pnpm --filter @workspace/royal-wedding-invite run typecheck
PORT=21903 BASE_PATH=/ pnpm --filter @workspace/royal-wedding-invite run build
```

The source is organized into page sections, wedding content, a countdown hook,
and the optional Three.js ambience component. The countdown currently targets
midnight IST at the start of October 24, 2026, because no ceremony time was
provided.