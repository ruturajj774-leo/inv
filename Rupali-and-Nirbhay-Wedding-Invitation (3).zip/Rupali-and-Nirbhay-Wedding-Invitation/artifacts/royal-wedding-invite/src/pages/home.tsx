import { useEffect, useRef } from 'react';
import { useReducedMotion, type Variants } from 'framer-motion';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Lenis from 'lenis';
import {
  ClosingSection,
  DateSection,
  HeroSection,
  InvitationFooter,
  InvitationHeader,
  StorySection,
  VenueSection,
} from '@/components/invitation/Sections';
import { useWeddingCountdown } from '@/hooks/useWeddingCountdown';
import { weddingDetails } from '@/lib/wedding-details';

const weddingTimestamp = new Date(weddingDetails.dateTime).getTime();
const countdownReferenceTime = new Date(
  weddingDetails.countdownReferenceTime,
).getTime();

export default function HomePage() {
  const reducedMotion = useReducedMotion();
  const pageRef = useRef<HTMLElement>(null);
  const countdown = useWeddingCountdown(
    weddingTimestamp,
    countdownReferenceTime,
  );

  useEffect(() => {
    if (reducedMotion || !pageRef.current) return;

    gsap.registerPlugin(ScrollTrigger);
    const lenis = new Lenis({
      autoRaf: false,
      duration: 1.05,
      smoothWheel: true,
      anchors: true,
    });
    lenis.on('scroll', ScrollTrigger.update);

    const tick = (time: number) => lenis.raf(time * 1000);
    gsap.ticker.add(tick);
    gsap.ticker.lagSmoothing(0);

    const context = gsap.context(() => {
      const hero = pageRef.current?.querySelector('.hero');
      const heroImage = pageRef.current?.querySelector('.hero-image');
      if (!hero || !heroImage) return;

      gsap.to(heroImage, {
        yPercent: 8,
        ease: 'none',
        scrollTrigger: {
          trigger: hero,
          start: 'top top',
          end: 'bottom top',
          scrub: 0.7,
          invalidateOnRefresh: true,
        },
      });
    }, pageRef);
    const refreshFrame = window.requestAnimationFrame(() =>
      ScrollTrigger.refresh(),
    );

    return () => {
      window.cancelAnimationFrame(refreshFrame);
      gsap.ticker.remove(tick);
      gsap.ticker.lagSmoothing(500, 33);
      lenis.destroy();
      context.revert();
    };
  }, [reducedMotion]);

  const reveal: Variants = {
    hidden: { opacity: 0, y: reducedMotion ? 0 : 28 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: reducedMotion ? 0 : 0.8,
        ease: [0.22, 1, 0.36, 1],
      },
    },
  };

  return (
    <main className="invitation noise" ref={pageRef}>
      <InvitationHeader />
      <HeroSection reducedMotion={reducedMotion} />
      <StorySection reveal={reveal} />
      <DateSection
        reveal={reveal}
        reducedMotion={reducedMotion}
        countdown={countdown}
      />
      <VenueSection reveal={reveal} />
      <ClosingSection reveal={reveal} />
      <InvitationFooter reveal={reveal} reducedMotion={reducedMotion} />
    </main>
  );
}