import { AnimatePresence, motion } from 'framer-motion';

interface TimeTileProps {
  value: number;
  label: string;
  reducedMotion: boolean | null;
}

export function TimeTile({ value, label, reducedMotion }: TimeTileProps) {
  const display = String(value).padStart(2, '0');
  const transition = {
    duration: reducedMotion ? 0 : 0.42,
    ease: [0.22, 1, 0.36, 1] as const,
  };

  return (
    <div className="time-tile" data-testid={`countdown-${label.toLowerCase()}`}>
      <div
        className="time-window"
        aria-label={`${display} ${label}`}
        data-testid={`text-countdown-${label.toLowerCase()}`}
      >
        <span className="sr-only">{display}</span>
        <span className="time-value" aria-hidden="true">
          {display.split('').map((digit, index) => (
            <span className="digit-slot" key={`${label}-${index}`}>
              <AnimatePresence initial={false} mode="sync">
                <motion.span
                  className="digit-face"
                  key={digit}
                  initial={
                    reducedMotion
                      ? false
                      : { y: '100%', rotateX: -85, opacity: 0 }
                  }
                  animate={{ y: 0, rotateX: 0, opacity: 1 }}
                  exit={{ y: '-100%', rotateX: 85, opacity: 0 }}
                  transition={transition}
                >
                  {digit}
                </motion.span>
              </AnimatePresence>
            </span>
          ))}
        </span>
      </div>
      <span className="time-label">{label}</span>
    </div>
  );
}