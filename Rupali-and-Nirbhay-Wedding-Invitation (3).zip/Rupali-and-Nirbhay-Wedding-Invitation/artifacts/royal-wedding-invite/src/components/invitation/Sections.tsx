import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion, type Variants } from 'framer-motion';
import {
  ArrowDown,
  ArrowUpRight,
  CalendarDays,
  Info,
  MapPin,
  Music2,
} from 'lucide-react';
import { TimeTile } from '@/components/invitation/TimeTile';
import { MonogramMark } from '@/components/invitation/MonogramMark';
import type { WeddingCountdown } from '@/hooks/useWeddingCountdown';
import { weddingDetails, weddingMapUrl } from '@/lib/wedding-details';

interface SectionMotionProps {
  reveal: Variants;
}

interface ReducedMotionSectionProps {
  reducedMotion: boolean | null;
}

interface DateSectionProps extends SectionMotionProps, ReducedMotionSectionProps {
  countdown: WeddingCountdown;
}

interface InvitationFooterProps extends SectionMotionProps {
  reducedMotion: boolean | null;
}

export function InvitationHeader() {
  return (
    <header className="topbar">
      <a
        className="monogram"
        href="#home"
        aria-label="Rupali and Nirbhay wedding invitation home"
        data-testid="link-home"
      >
        <MonogramMark />
      </a>
      <nav aria-label="Invitation sections">
        <a href="#story" data-testid="link-story">
          A little story
        </a>
        <a href="#when" data-testid="link-wedding-day">
          The day
        </a>
        <a href="#place" data-testid="link-venue">
          The place
        </a>
      </nav>
      <a
        href="#place"
        className="topbar-date"
        data-testid="link-wedding-date"
      >
        24 · 10 · 26 <ArrowUpRight size={13} />
      </a>
    </header>
  );
}

export function HeroSection({ reducedMotion }: ReducedMotionSectionProps) {
  const heroGroup: Variants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: reducedMotion ? 0 : 0.12,
        delayChildren: reducedMotion ? 0 : 0.08,
      },
    },
  };
  const heroItem: Variants = {
    hidden: { opacity: 0, y: reducedMotion ? 0 : 16 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: reducedMotion ? 0 : 0.7,
        ease: [0.22, 1, 0.36, 1],
      },
    },
  };

  return (
    <section className="hero" id="home" aria-labelledby="couple-title">
      <div className="hero-image" aria-hidden="true" />
      <div className="ambient-fallback" aria-hidden="true" />
      <div className="hero-vignette" aria-hidden="true" />
      <div className="hero-arch arch-one" aria-hidden="true" />
      <div className="hero-arch arch-two" aria-hidden="true" />
      <motion.div
        className="hero-content"
        variants={heroGroup}
        initial="hidden"
        animate="visible"
      >
        <motion.div className="eyebrow" variants={heroItem}>
          <span className="eyebrow-line" />
          {weddingDetails.invitationKicker}
          <span className="eyebrow-line" />
        </motion.div>
        <motion.p className="hero-invite" variants={heroItem}>
          {weddingDetails.invitationLine} <span lang="mr">सहकुटुंब</span>
        </motion.p>
        <motion.h1
          className="couple-title"
          id="couple-title"
          data-testid="text-couple-names"
          variants={heroItem}
        >
          <span>{weddingDetails.bride}</span>
          <em>&amp;</em>
          <span>{weddingDetails.groom}</span>
        </motion.h1>
        <motion.div className="hero-divider" variants={heroItem}>
          <span />
        </motion.div>
        <motion.p
          className="hero-date"
          data-testid="text-wedding-date"
          variants={heroItem}
        >
          Saturday <i /> 24 October 2026
        </motion.p>
        <motion.p
          className="hero-city"
          data-testid="text-wedding-location"
          variants={heroItem}
        >
          Nashik, Maharashtra
        </motion.p>
        <motion.a
          className="scroll-cue"
          href="#story"
          aria-label="Scroll to discover the invitation"
          data-testid="link-scroll-invitation"
          variants={heroItem}
        >
          <span>Enter the celebration</span>
          <ArrowDown size={15} strokeWidth={1.5} />
        </motion.a>
      </motion.div>
      <div className="hero-side-note" aria-hidden="true">
        A DAY TO REMEMBER · NASHIK
      </div>
      <div className="hero-corner top-left" aria-hidden="true">
      </div>
      <div className="hero-corner top-right" aria-hidden="true">
      </div>
    </section>
  );
}

export function StorySection({ reveal }: SectionMotionProps) {
  return (
    <section className="story-section velvet" id="story">
      <span className="velvet-nap" aria-hidden="true" />
      <div className="story-orbit" aria-hidden="true">
        <span>R</span>
        <i aria-hidden="true" />
        <span>N</span>
      </div>
      <motion.div
        className="story-copy"
        variants={reveal}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.35 }}
      >
        <p className="section-kicker">
          A note from the two of us <span lang="mr">आमच्या मनोगतातून</span>
        </p>
        <h2>
          Some days become
          <br />
          <em>part of your story.</em>
        </h2>
        <p className="story-body">
          Ours is beginning with a promise, surrounded by the people who have
          made us who we are. We would be honoured to have you beside us as we
          take this next step—one shared smile, one blessing, one beautiful
          memory at a time.
        </p>
        <p className="story-signature">
          With love,{' '}
          <span>
            {weddingDetails.bride} &amp; {weddingDetails.groom}
          </span>
        </p>
      </motion.div>
      <div className="story-side-ornament" aria-hidden="true">
        <span />
        <div />
        <span />
      </div>
    </section>
  );
}

export function DateSection({
  reveal,
  reducedMotion,
  countdown,
}: DateSectionProps) {
  return (
    <section className="date-section velvet" id="when">
      <span className="velvet-nap" aria-hidden="true" />
      <div className="date-inner">
        <motion.div
          variants={reveal}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.35 }}
        >
          <p className="section-kicker dark-kicker">
            The day we become a little more us <span lang="mr">शुभ दिवस</span>
          </p>
          <h2 className="date-heading">
            A date to <em>hold close.</em>
          </h2>
          <div className="calendar-mark">
            <span>OCT</span>
            <strong data-testid="text-wedding-day-number">24</strong>
            <small>2026</small>
          </div>
          <p className="date-description">Saturday, 24 October 2026</p>
        </motion.div>
        <motion.div
          className="countdown-panel"
          variants={reveal}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.35 }}
        >
          <div className="countdown-heading">
            <span>
          Until our forever begins <span lang="mr">लग्नापर्यंत उरलेला वेळ</span>
            </span>
            <Music2 size={15} strokeWidth={1.4} />
          </div>
          <div
            className="countdown"
            aria-live="off"
            data-testid="status-wedding-countdown"
          >
            <TimeTile
              value={countdown.days}
              label="Days"
              reducedMotion={reducedMotion}
            />
            <span className="count-sep">:</span>
            <TimeTile
              value={countdown.hours}
              label="Hours"
              reducedMotion={reducedMotion}
            />
            <span className="count-sep">:</span>
            <TimeTile
              value={countdown.minutes}
              label="Minutes"
              reducedMotion={reducedMotion}
            />
            <span className="count-sep">:</span>
            <TimeTile
              value={countdown.seconds}
              label="Seconds"
              reducedMotion={reducedMotion}
            />
          </div>
          <p className="countdown-foot">
            The moments are already counting themselves.
          </p>
        </motion.div>
      </div>
    </section>
  );
}

export function VenueSection({ reveal }: SectionMotionProps) {
  return (
    <section className="venue-section velvet" id="place">
      <span className="velvet-nap" aria-hidden="true" />
      <div className="venue-frame">
        <motion.div
          className="venue-content"
          variants={reveal}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
        >
          <div className="venue-icon">
            <MapPin size={21} strokeWidth={1.25} />
          </div>
          <p className="section-kicker">
            Our gathering place <span lang="mr">आपले हार्दिक स्वागत आहे</span>
          </p>
          <h2>
            Meet us <em>in Nashik.</em>
          </h2>
          <div className="venue-rule">
            <span />
          </div>
          <h3 data-testid="text-venue-name">{weddingDetails.venue}</h3>
          <p className="venue-address" data-testid="text-venue-address">
            {weddingDetails.address}
          </p>
          <p className="venue-note">
            We look forward to welcoming you
            <br />
            for a day filled with love and togetherness.
          </p>
          <a
            className="map-link"
            href={weddingMapUrl}
            target="_blank"
            rel="noreferrer"
            data-testid="link-venue-map"
          >
            View on Map <span lang="mr">नकाशा पाहा</span>
            <ArrowUpRight size={14} />
          </a>
          <p className="venue-date">
            <CalendarDays size={15} /> {weddingDetails.dateLabel}
          </p>
        </motion.div>
      </div>
      <div className="venue-flourish" aria-hidden="true">
      </div>
    </section>
  );
}

export function ClosingSection({ reveal }: SectionMotionProps) {
  return (
    <section className="closing-section velvet">
      <span className="velvet-nap" aria-hidden="true" />
      <motion.div
        className="closing-content"
        variants={reveal}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.45 }}
      >
        <div className="closing-star" aria-hidden="true" />
        <p className="section-kicker dark-kicker">Until then</p>
        <h2>
          Keep a little
          <br />
          <em>room for joy.</em>
        </h2>
        <p>We cannot wait to celebrate with you.</p>
        <span className="closing-names">
          {weddingDetails.bride} <b>&amp;</b> {weddingDetails.groom}
        </span>
      </motion.div>
    </section>
  );
}

export function InvitationFooter({
  reveal,
  reducedMotion,
}: InvitationFooterProps) {
  const [showCredit, setShowCredit] = useState(false);
  const footerInfoRef = useRef<HTMLDivElement>(null);
  const creditButtonRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!showCredit) return;

    const closeOnOutsidePointer = (event: PointerEvent) => {
      if (
        event.target instanceof Node &&
        !footerInfoRef.current?.contains(event.target)
      ) {
        setShowCredit(false);
      }
    };
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setShowCredit(false);
        creditButtonRef.current?.focus();
      }
    };

    document.addEventListener('pointerdown', closeOnOutsidePointer);
    document.addEventListener('keydown', closeOnEscape);
    return () => {
      document.removeEventListener('pointerdown', closeOnOutsidePointer);
      document.removeEventListener('keydown', closeOnEscape);
    };
  }, [showCredit]);

  return (
    <motion.footer
      className="footer"
      variants={reveal}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, amount: 0.25 }}
    >
      <MonogramMark className="footer-monogram" />
      <p>Crafted with love by Ruturaj Jadhav</p>
      <div
        className="footer-info"
        ref={footerInfoRef}
        onMouseEnter={() => setShowCredit(true)}
        onMouseLeave={() => setShowCredit(false)}
      >
        <button
          ref={creditButtonRef}
          className="credit-trigger"
          type="button"
          aria-label="Developer details and tools used"
          title="Developer details and tools used"
          aria-expanded={showCredit}
          aria-controls="developer-card"
          data-testid="button-developer-info"
          onClick={(event) => {
            const isHoverPointer =
              window.matchMedia('(hover: hover)').matches && event.detail > 0;
            setShowCredit(isHoverPointer ? true : (open) => !open);
          }}
        >
          <span className="info-mark">
            <Info size={14} strokeWidth={1.5} />
          </span>
        </button>
        <AnimatePresence>
          {showCredit && (
            <motion.div
              className="credit-reveal"
              id="developer-card"
              role="region"
              aria-labelledby="developer-card-title"
              initial={{ opacity: 0, y: 8, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 6, scale: 0.98 }}
              transition={{ duration: reducedMotion ? 0 : 0.25 }}
            >
              <span className="credit-kicker">Design &amp; development</span>
              <strong id="developer-card-title">Ruturaj Jadhav</strong>
              <p className="credit-subtitle">
                Created for Rupali &amp; Nirbhay
              </p>
              <div className="credit-divider" aria-hidden="true">
                <span />
              </div>
              <p className="credit-stack-title">Made with</p>
              <dl className="credit-stack">
                <div>
                  <dt>Core</dt>
                  <dd>React · TypeScript · Vite</dd>
                </div>
                <div>
                  <dt>Motion</dt>
                  <dd>Framer Motion · GSAP ScrollTrigger · Lenis</dd>
                </div>
                <div>
                  <dt>Styling</dt>
                  <dd>Tailwind CSS · custom CSS · SVG</dd>
                </div>
                <div>
                  <dt>Icons &amp; type</dt>
                  <dd>
                    Lucide React · Cormorant Garamond · Inter · Noto Sans
                    Devanagari
                  </dd>
                </div>
              </dl>
              <p className="credit-stack-title credit-footprint-title">
                Project footprint
              </p>
              <dl className="credit-stack credit-footprint">
                <div>
                  <dt>Source</dt>
                  <dd>80 files · about 413 KiB</dd>
                </div>
                <div>
                  <dt>Build</dt>
                  <dd>Optimized HTML, CSS, JavaScript &amp; palace image</dd>
                </div>
              </dl>
              <details className="credit-file-details">
                <summary>Key project files</summary>
                <ul>
                  <li>
                    <code>src/App.tsx</code>, <code>src/pages/home.tsx</code>
                    {' '}— app entry and invitation flow
                  </li>
                  <li>
                    <code>src/components/invitation/</code> — invitation,
                    countdown and monogram
                  </li>
                  <li>
                    <code>src/hooks/useWeddingCountdown.ts</code>,
                    {' '}<code>src/lib/wedding-details.ts</code> — countdown
                    and wedding details
                  </li>
                  <li>
                    <code>src/index.css</code>,
                    {' '}<code>src/assets/palace-hall.jpg</code> — visual
                    design and backdrop
                  </li>
                  <li>
                    <code>package.json</code>,
                    {' '}<code>vite.config.ts</code>,
                    {' '}<code>tsconfig.json</code> — dependencies and build
                    settings
                  </li>
                </ul>
              </details>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      <div className="footer-bottom">
        <span>
          {weddingDetails.bride} &amp; {weddingDetails.groom}
        </span>
        <span>24 · 10 · 2026</span>
      </div>
    </motion.footer>
  );
}