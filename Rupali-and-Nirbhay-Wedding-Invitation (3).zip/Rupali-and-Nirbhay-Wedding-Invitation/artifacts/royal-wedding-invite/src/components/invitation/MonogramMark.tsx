import { useId } from 'react';

interface MonogramMarkProps {
  className?: string;
}

export function MonogramMark({ className }: MonogramMarkProps) {
  const gradientId = `monogram-gold-${useId().replace(/:/g, '')}`;

  return (
    <svg
      className={className ? `monogram-crest ${className}` : 'monogram-crest'}
      viewBox="0 0 96 96"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
      focusable="false"
    >
      <defs>
        <linearGradient
          id={gradientId}
          x1="12"
          y1="12"
          x2="84"
          y2="84"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#f4dfaa" />
          <stop offset=".48" stopColor="#b88947" />
          <stop offset="1" stopColor="#f0d28b" />
        </linearGradient>
      </defs>

      <g
        className="monogram-rotating-ring"
        stroke={`url(#${gradientId})`}
        strokeWidth=".8"
      >
        <circle cx="48" cy="48" r="43" />
        <circle cx="48" cy="48" r="39" strokeDasharray="1 4.5" />
        {Array.from({ length: 12 }, (_, index) => (
          <path
            key={index}
            d="M48 7.5C43.5 12 43.5 17.5 48 21C52.5 17.5 52.5 12 48 7.5Z"
            transform={`rotate(${index * 30} 48 48)`}
          />
        ))}
      </g>

      <circle
        cx="48"
        cy="48"
        r="30"
        stroke={`url(#${gradientId})`}
        strokeWidth=".9"
      />
      <circle
        cx="48"
        cy="48"
        r="26"
        stroke={`url(#${gradientId})`}
        strokeWidth=".55"
        strokeDasharray="1 3.5"
      />
      <path
        d="M28 48H34M62 48H68"
        stroke={`url(#${gradientId})`}
        strokeWidth=".8"
      />
      <text
        x="48"
        y="53"
        fill={`url(#${gradientId})`}
        textAnchor="middle"
        fontFamily="'Cormorant Garamond', serif"
        fontSize="20"
        fontWeight="600"
        letterSpacing=".7"
      >
        R<tspan fontSize="13" fontStyle="italic"> &amp; </tspan>N
      </text>
    </svg>
  );
}