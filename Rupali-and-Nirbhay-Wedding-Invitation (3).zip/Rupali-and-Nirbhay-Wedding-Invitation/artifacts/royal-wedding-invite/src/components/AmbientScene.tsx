import { Component, type ReactNode, useEffect, useMemo, useRef, useState } from 'react';
import { AdaptiveDpr } from '@react-three/drei';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';

class WebGLFallbackBoundary extends Component<
  { children: ReactNode },
  { failed: boolean }
> {
  state = { failed: false };

  static getDerivedStateFromError() {
    return { failed: true };
  }

  render() {
    if (this.state.failed) return <div className="ambient-fallback" aria-hidden="true" />;
    return this.props.children;
  }
}

function GoldDust() {
  const pointsRef = useRef<THREE.Points>(null);
  const geometry = useMemo(() => {
    const position = new Float32Array(108 * 3);
    const noise = (seed: number) => {
      const value = Math.sin((seed + 1) * 12.9898) * 43758.5453;
      return value - Math.floor(value);
    };

    for (let index = 0; index < 108; index += 1) {
      position[index * 3] = (noise(index * 3) - 0.5) * 12;
      position[index * 3 + 1] = (noise(index * 3 + 1) - 0.5) * 7;
      position[index * 3 + 2] = (noise(index * 3 + 2) - 0.5) * 3;
    }

    const buffer = new THREE.BufferGeometry();
    buffer.setAttribute('position', new THREE.Float32BufferAttribute(position, 3));
    return buffer;
  }, []);

  useEffect(() => () => geometry.dispose(), [geometry]);

  useFrame(({ clock }) => {
    if (!pointsRef.current) return;
    pointsRef.current.rotation.y = Math.sin(clock.elapsedTime * 0.11) * 0.08;
    pointsRef.current.rotation.x = Math.sin(clock.elapsedTime * 0.08) * 0.025;
  });

  return (
    <points ref={pointsRef} geometry={geometry}>
      <pointsMaterial
        color="#e0c486"
        size={1.8}
        transparent
        opacity={0.38}
        depthWrite={false}
        sizeAttenuation={false}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
}

export default function AmbientScene() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [nearViewport, setNearViewport] = useState(false);

  useEffect(() => {
    const element = containerRef.current;
    if (!element) return;

    const observer = new IntersectionObserver(
      ([entry]) => setNearViewport(entry.isIntersecting),
      { rootMargin: '120px' },
    );
    observer.observe(element);
    return () => observer.disconnect();
  }, []);

  return (
    <div className="ambient-scene" ref={containerRef} aria-hidden="true">
      {nearViewport && (
        <WebGLFallbackBoundary>
          <Canvas
            dpr={[1, 1.5]}
            camera={{ position: [0, 0, 7], fov: 46 }}
            gl={{ alpha: true, antialias: false, powerPreference: 'low-power' }}
          >
            <AdaptiveDpr pixelated />
            <GoldDust />
          </Canvas>
        </WebGLFallbackBoundary>
      )}
    </div>
  );
}