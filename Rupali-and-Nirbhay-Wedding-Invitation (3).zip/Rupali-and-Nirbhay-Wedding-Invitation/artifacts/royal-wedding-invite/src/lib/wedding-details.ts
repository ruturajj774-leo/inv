export const weddingDetails = {
  bride: 'Rupali',
  groom: 'Nirbhay',
  invitationLine: 'Together with their families',
  invitationKicker: 'Celebrate the wedding of',
  dateTime: '2026-10-24T00:00:00+05:30',
  countdownReferenceTime: '2026-10-02T00:00:00+05:30',
  dateLabel: 'Saturday, 24 October 2026',
  venue: 'Ganadhish Banquet Hall',
  address:
    'TDP Nagar, 2QWQ+GV2, Makhmalabad Road, Mhasrul Gaon, Ashwamegh Nagar, Makhmalabad, Nashik, Maharashtra 422003',
} as const;

export const weddingMapUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
  `${weddingDetails.venue}, ${weddingDetails.address}`,
)}`;