import { useEffect, useState } from 'react';

export interface WeddingCountdown {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

export function useWeddingCountdown(
  targetTime: number,
  referenceTime: number,
): WeddingCountdown {
  const [now, setNow] = useState(() => Math.max(Date.now(), referenceTime));

  useEffect(() => {
    if (Date.now() >= targetTime) {
      setNow(targetTime);
      return;
    }

    const intervalId = window.setInterval(() => {
      const currentTime = Date.now();
      setNow(currentTime);
      if (currentTime >= targetTime) {
        window.clearInterval(intervalId);
      }
    }, 1000);
    return () => window.clearInterval(intervalId);
  }, [targetTime]);

  const remaining = Math.max(0, targetTime - Math.max(now, referenceTime));

  return {
    days: Math.floor(remaining / 86_400_000),
    hours: Math.floor((remaining % 86_400_000) / 3_600_000),
    minutes: Math.floor((remaining % 3_600_000) / 60_000),
    seconds: Math.floor((remaining % 60_000) / 1000),
  };
}