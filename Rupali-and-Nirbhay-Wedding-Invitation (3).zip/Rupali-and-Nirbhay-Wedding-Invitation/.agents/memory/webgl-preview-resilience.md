---
name: WebGL preview resilience
description: Replit preview limitations for optional Three.js visuals and graceful rendering.
---

A browser preview may be unable to create a WebGL context even when the production site can use WebGL. Keep GPU-only visuals optional and isolated, with a CSS fallback that leaves the main page intact.

**Why:** The proxied preview browser did not expose a usable WebGL context; an uncaught renderer error replaced the page until the effect was isolated.

**How to apply:** For R3F/Three.js ambience, lazy-load it, cap DPR, and wrap it in an error boundary with a lightweight CSS fallback. Verify the core page independently of that optional layer.