---
name: Invitation copy language
description: Standing language and content constraints for the Rupali and Nirbhay wedding invitation.
---

Keep the invitation English-first with a little Marathi, and do not mention AI anywhere on the site.

**Why:** The user requested these constraints for this invitation.

**How to apply:** Keep future invitation copy consistent with this language mix and content restriction.